#ifndef DOUBLE_LINKED_LIST_H
#define DOUBLE_LINKED_LIST_H

#define TAIL -99

typedef float WType;

typedef struct _double_linked_list_data
{
	int num;
	WType weight;
}LData;

typedef struct _double_linked_list_node
{
	struct _double_linked_list_node *next;
	struct _double_linked_list_node *prev;
	int index;
	LData data;
}DLinkedNode;

typedef struct _double_linked_list
{
	struct _double_linked_list_node *head;
	struct _double_linked_list_node *tail;
	int NumofNode;
}DLinkedList;

/* It create and initalize newnode and
returns newnode's adress */
DLinkedNode *CreateNode(void);
/*intializes node */
void InitNode(DLinkedNode *node);
/*sets node's data */
void SetNodeData(DLinkedNode *node, LData data);
/*inserts node to list */
void InsertNode(DLinkedList *list, DLinkedNode *node);
/*sets node's data */
void SetNodeData(DLinkedNode *node, LData data);
/* initalizes list */
void InitList(DLinkedList *list);

#endif