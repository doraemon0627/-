#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "double_linked_list.h"

DLinkedNode *CreateNode(void)
{
	DLinkedNode *newnode;

	newnode = calloc(1, sizeof(DLinkedNode));

	if (newnode == NULL)
	{
		fprintf(stderr, "exception : CreateNode() cannot allocate");
		return NULL;
	}
	newnode->index = -1;

	return newnode;
}

void SetNodeData(DLinkedNode *node, LData data)
{
	if (node == NULL)
	{
		fprintf(stderr, "exception : SetNodeData() node is NULL\n");
		return;
	}

	node->data.num = data.num;
	node->data.weight = data.weight;
}

void InitList(DLinkedList *list)
{
	if (list == NULL)
	{
		fprintf(stderr, "exception : InitList() list is NULL\n");
		return;
	}
	
	list->head = NULL;
	list->tail = calloc(1, sizeof(DLinkedNode)); /* dummy node */
	list->tail->index = TAIL;
	
	if (list->tail == NULL)
	{
		fprintf(stderr, "exception : InitList() cannot allocate\n");
		return;
	}

	list->NumofNode = 0;

}

void InitNode(DLinkedNode *node)
{
	LData data;

	if (node == NULL)
	{
		fprintf(stderr, "exception : InitNode() node is NULL\n");
		return;
	}

	data.num = 0;
	data.weight = 0;

	node->prev = NULL;
	node->next = NULL;
	node->index = -1;

	SetNodeData(node, data);
}

void InsertNode(DLinkedList *list, DLinkedNode *node)
{
	DLinkedNode *currentnode;

	if (list == NULL)
	{
		fprintf(stderr, "exception : InsertNode() list is NULL\n");
		return;
	}
	else if (node == NULL)
	{
		fprintf(stderr, "exception : InsertNode() node is NULL\n");
		return;
	}
	else
	{
		if (list->head == NULL)
		{
			list->head = node;
			node->prev = node;
			
			node->next = list->tail;
			list->tail->prev = node;
		}
		else
		{
		currentnode = list->head;

		while(currentnode->next != list->tail)
			currentnode = currentnode->next;

		currentnode->next = node;
		node->prev = currentnode;
		
		node->next = list->tail;
		list->tail->prev = node;
		}
	}
}
