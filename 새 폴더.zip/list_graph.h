#ifndef LIST_GRAPH_H
#define LIST_GRAPH_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "double_linked_list.h"

enum {A = 0, B, C, D, E, F, G};

/* It returns CreateNode() */
DLinkedNode *CreateVertex(void);
/* Sets vertex's index and data */
void SetVertex(DLinkedNode *vertex, int index, LData data);
/* Connets "to" to list */
void ConnectVertex(DLinkedList *from, DLinkedNode *to);

#endif