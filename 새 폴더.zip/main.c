#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "double_linked_list.h"
#include "list_graph.h"

int main(void)
{
	/*

	--------------"a"<-------->"b"
	-------------/-------------^
	------------v--v==========
	------------"c"
	*/

	int i;
	LData dummy;
	DLinkedList lists[10] = {0};

	DLinkedNode *a, *b, *c;

	dummy.num = 0;
	dummy.weight = 0;
	
	for (i =0; i< 10; i++)
		InitList(&lists[i]);

	a = CreateVertex();
	b = CreateVertex();
	c = CreateVertex();

	SetVertex(a, A, dummy);
	SetVertex(b, B, dummy);
	SetVertex(c, C, dummy);

	ConnectVertex(&lists[A], c);
	ConnectVertex(&lists[A], b);

	ConnectVertex(&lists[B], a);
	ConnectVertex(&lists[B], c);

	ConnectVertex(&lists[C], b);

	printf("%d", B);
	return 0;
}