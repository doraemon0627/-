#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "double_linked_list.h"

DLinkedNode *CreateVertex(void)
{
	DLinkedNode *newnode = CreateNode();

	if (newnode == NULL)
	{
		fprintf(stderr, "exception : CreateVertex() cannot allocate\n");
		return NULL;
	}
	InitNode(newnode);

	return newnode;
}

void SetVertex(DLinkedNode *vertex, int index, LData data)
{
	if (vertex == NULL)
	{
		fprintf(stderr, "exception : SetVertex() vertex is NULL\n");
		return;
	}
	else
	{
		vertex->index = index;
		SetNodeData(vertex, data);
	}
}

void ConnectVertex(DLinkedList *from, DLinkedNode *to)
{
	if (from == NULL)
	{
		fprintf(stderr, "exception : ConnectVertex() from is NULL\n");
		return;
	}
	else if (to == NULL)
	{
		fprintf(stderr, "exception : ConnectVertex() to is NULL\n");
		return;
	}
	else if (to->index == -1)
	{
		fprintf(stderr, "exception : ConnectVertex() to's index is NULL\n");
		return;
	}
	else
		InsertNode(from, to);
}

